package com.tiersmod;

import java.util.*;

public class TierManager {

    private static final Map<UUID, String> CACHE = new HashMap<>();
    private static int tick = 0;

    public static void tick(net.minecraft.client.MinecraftClient client) {
        tick++;
        if (tick % 100 == 0 && client.player != null) {
            CACHE.put(client.player.getUuid(), "HT1");
        }
    }

    public static String getTier(UUID uuid) {
        return CACHE.getOrDefault(uuid, "UNRANKED");
    }
}
