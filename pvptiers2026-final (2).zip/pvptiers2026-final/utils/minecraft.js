const fetch = require('node-fetch');

/**
 * Resolve Minecraft username to UUID via Mojang API
 * Returns { id, name } or null
 */
async function resolveUsername(username) {
  if (!username || typeof username !== 'string') return null;
  const clean = username.trim().slice(0, 16);
  if (!/^[a-zA-Z0-9_]{1,16}$/.test(clean)) return null;

  try {
    const res = await fetch(`https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(clean)}`, {
      timeout: 8000
    });
    if (res.status === 204 || res.status === 404) return null;
    if (!res.ok) return null;
    const data = await res.json();
    // Mojang returns id without dashes
    return {
      id: data.id,
      name: data.name
    };
  } catch (e) {
    console.error('Mojang API error:', e.message);
    return null;
  }
}

/**
 * Format UUID with dashes
 */
function formatUuid(id) {
  if (!id || id.length !== 32) return id;
  return `${id.slice(0, 8)}-${id.slice(8, 12)}-${id.slice(12, 16)}-${id.slice(16, 20)}-${id.slice(20)}`;
}

module.exports = { resolveUsername, formatUuid };
