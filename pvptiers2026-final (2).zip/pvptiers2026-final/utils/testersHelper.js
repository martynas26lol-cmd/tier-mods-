const { load } = require('./dataStore');
const config = require('../config');

// Cooldown between tests of the same mode (default 1 day)
const COOLDOWN_MS = config.cooldownMs || (24 * 60 * 60 * 1000);

/**
 * Returns array of online tester objects that can test the given mode.
 * If mode is 'any' or null, returns all online testers.
 */
function getOnlineTestersForMode(mode) {
  const testers = load('testers');
  const online = Object.values(testers).filter(t => t.online);

  if (!mode || mode === 'any') {
    return online;
  }

  return online.filter(t => {
    if (!t.modes || t.modes.length === 0) return true; // all modes
    return t.modes.map(m => m.toLowerCase()).includes(mode.toLowerCase());
  });
}

/**
 * Check if there is at least one online tester for the mode.
 */
function hasTesterForMode(mode) {
  return getOnlineTestersForMode(mode).length > 0;
}

/**
 * Get modes a member can test based on their roles.
 */
function getModesFromRoles(member) {
  const modes = [];
  for (const [mode, roleId] of Object.entries(config.roles.testers)) {
    if (member.roles.cache.has(roleId)) {
      modes.push(mode);
    }
  }
  return modes;
}

/**
 * Get last test timestamp for a player (most recent from results).
 * Returns { timestamp, mode, rank } or null
 */
function getLastTest(playerId) {
  const results = load('results');
  if (!Array.isArray(results.history)) return null;

  const entry = results.history.find(r => r.playerId === playerId);
  if (!entry) return null;

  return {
    timestamp: entry.timestamp,
    mode: entry.mode,
    newRank: entry.newRank,
    previousRank: entry.previousRank
  };
}

/**
 * Get last test per mode for a player
 */
function getLastTestsByMode(playerId) {
  const results = load('results');
  if (!Array.isArray(results.history)) return {};

  const byMode = {};
  for (const r of results.history) {
    if (r.playerId === playerId && r.mode && !byMode[r.mode]) {
      byMode[r.mode] = {
        timestamp: r.timestamp,
        newRank: r.newRank,
        previousRank: r.previousRank
      };
    }
  }
  return byMode;
}

/**
 * Check if player is still on cooldown for a mode (or any mode if mode is 'any'/null).
 * Returns { onCooldown: boolean, remainingMs: number, lastTimestamp: number|null, mode: string|null }
 */
function getCooldownStatus(playerId, mode) {
  const byMode = getLastTestsByMode(playerId);
  const now = Date.now();

  // If specific mode requested
  if (mode && mode !== 'any') {
    const last = byMode[mode];
    if (!last) {
      return { onCooldown: false, remainingMs: 0, lastTimestamp: null, mode: null };
    }
    const remaining = last.timestamp + COOLDOWN_MS - now;
    if (remaining > 0) {
      return { onCooldown: true, remainingMs: remaining, lastTimestamp: last.timestamp, mode };
    }
    return { onCooldown: false, remainingMs: 0, lastTimestamp: last.timestamp, mode };
  }

  // mode === 'any' → check the most recent test of any mode
  const lastOverall = getLastTest(playerId);
  if (!lastOverall) {
    return { onCooldown: false, remainingMs: 0, lastTimestamp: null, mode: null };
  }
  const remaining = lastOverall.timestamp + COOLDOWN_MS - now;
  if (remaining > 0) {
    return {
      onCooldown: true,
      remainingMs: remaining,
      lastTimestamp: lastOverall.timestamp,
      mode: lastOverall.mode
    };
  }
  return { onCooldown: false, remainingMs: 0, lastTimestamp: lastOverall.timestamp, mode: lastOverall.mode };
}

/**
 * Format remaining time nicely (e.g. "1d 5h 23m")
 */
function formatRemaining(ms) {
  if (ms <= 0) return '0m';
  const totalMinutes = Math.ceil(ms / 60000);
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0 || parts.length === 0) parts.push(`${minutes}m`);
  return parts.join(' ');
}

/**
 * Check if a user is currently banned from testing.
 * Returns { banned: boolean, reason, expiresAt, bannedBy, days } or null if not banned / expired
 */
function getBanStatus(userId) {
  const bans = load('bans');
  const ban = bans[userId];
  if (!ban) return null;

  if (ban.expiresAt && Date.now() > ban.expiresAt) {
    // Auto-clean expired
    delete bans[userId];
    const { save } = require('./dataStore');
    save('bans', bans);
    return null;
  }

  return {
    banned: true,
    reason: ban.reason || 'No reason provided',
    bannedBy: ban.bannedBy,
    bannedAt: ban.bannedAt,
    expiresAt: ban.expiresAt,
    days: ban.days
  };
}

function isBanned(userId) {
  return !!getBanStatus(userId);
}

module.exports = {
  COOLDOWN_MS,
  getOnlineTestersForMode,
  hasTesterForMode,
  getModesFromRoles,
  getLastTest,
  getLastTestsByMode,
  getCooldownStatus,
  formatRemaining,
  getBanStatus,
  isBanned
};
