const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

function buildQueuePanel() {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('📋 Testing Queue')
    .setDescription(
      '**Players** → Join / Leave\n' +
      '**Testers** → View Queue → Accept\n\n' +
      '✅ Verified required  •  🧪 Online tester required\n' +
      '⏳ Cooldown **1 day**  •  🚫 Banned cannot join'
    )
    .setFooter({ text: 'pvptiers2026 • /testeronline to go online' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('queue_join')
      .setLabel('Join')
      .setStyle(ButtonStyle.Success)
      .setEmoji('➕'),
    new ButtonBuilder()
      .setCustomId('queue_leave')
      .setLabel('Leave')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('➖'),
    new ButtonBuilder()
      .setCustomId('queue_view')
      .setLabel('View Queue')
      .setStyle(ButtonStyle.Primary)
      .setEmoji('👀')
  );

  return { embeds: [embed], components: [row] };
}

module.exports = { buildQueuePanel };
