const { EmbedBuilder } = require('discord.js');
const { getLastTest } = require('./testersHelper');

function createResultEmbed({
  playerName,
  playerDiscordId,
  playerUuid,
  testerName,
  mode,
  previousRank,
  newRank,
  region = 'EU',
  stats = null,
  notes = null
}) {
  const embed = new EmbedBuilder()
    .setColor(newRank && newRank !== 'Unranked' ? 0x00ff88 : 0x5865f2)
    .setTitle(`🏆 ${mode.toUpperCase()}  •  ${newRank || 'Unranked'}`)
    .setDescription(`**${playerName}**${playerDiscordId ? `  <@${playerDiscordId}>` : ''}`)
    .addFields(
      { name: 'Tester', value: testerName || '—', inline: true },
      { name: 'Region', value: region, inline: true },
      { name: 'Previous', value: previousRank || 'Unranked', inline: true }
    )
    .setTimestamp()
    .setFooter({ text: 'pvptiers2026' });

  if (playerUuid) {
    embed.setThumbnail(`https://mc-heads.net/avatar/${playerUuid}/80`);
  }
  if (stats) {
    embed.addFields({ name: 'Stats', value: stats, inline: false });
  }
  if (notes) {
    embed.addFields({ name: 'Notes', value: notes, inline: false });
  }
  return embed;
}

function createTestersStatusEmbed(onlineTesters, capacity) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('🧪 Online Testers')
    .setFooter({ text: 'pvptiers2026' })
    .setTimestamp();

  if (!onlineTesters || onlineTesters.length === 0) {
    embed.setDescription(`None online\nCapacity: **0 / ${capacity}**`);
    return embed;
  }

  const lines = onlineTesters.map((t, i) => {
    const modes = t.modes && t.modes.length ? t.modes.join(', ') : 'all';
    return `**${i + 1}.** <@${t.discordId}>  \`${modes}\``;
  });

  embed.setDescription(lines.join('\n'));
  embed.addFields({ name: 'Capacity', value: `**${onlineTesters.length} / ${capacity}**`, inline: true });
  return embed;
}

function createQueueEmbed(queue) {
  const embed = new EmbedBuilder()
    .setColor(0xfaa61a)
    .setTitle('📋 Queue')
    .setFooter({ text: 'pvptiers2026' })
    .setTimestamp();

  if (!queue || queue.length === 0) {
    embed.setDescription('Empty');
    return embed;
  }

  const lines = queue.map((q, i) => {
    const last = getLastTest(q.discordId);
    let lastText = last ? ` • <t:${Math.floor(last.timestamp / 1000)}:R>` : '';
    return `**${i + 1}.** <@${q.discordId}> \`${q.username || '?'}\`  •  \`${(q.mode || 'any').toUpperCase()}\`  •  <t:${Math.floor(q.joinedAt / 1000)}:R>${lastText}`;
  });

  embed.setDescription(lines.join('\n'));
  if (queue[0]?.uuid) {
    embed.setThumbnail(`https://mc-heads.net/avatar/${queue[0].uuid}/64`);
  }
  return embed;
}

module.exports = {
  createResultEmbed,
  createTestersStatusEmbed,
  createQueueEmbed
};
