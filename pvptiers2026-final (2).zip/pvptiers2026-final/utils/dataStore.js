const fs = require('fs');
const path = require('path');
const config = require('../config');

function ensureDataDir() {
  const dir = path.join(__dirname, '..', 'data');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function load(fileKey) {
  ensureDataDir();
  const filePath = path.resolve(__dirname, '..', config.dataFiles[fileKey] || `./data/${fileKey}.json`);
  try {
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(raw || '{}');
    }
  } catch (e) {
    console.error(`Error loading ${fileKey}:`, e.message);
  }
  return fileKey === 'settings' ? { capacity: config.defaultCapacity } : {};
}

function save(fileKey, data) {
  ensureDataDir();
  const filePath = path.resolve(__dirname, '..', config.dataFiles[fileKey] || `./data/${fileKey}.json`);
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error(`Error saving ${fileKey}:`, e.message);
    return false;
  }
}

module.exports = { load, save, ensureDataDir };
