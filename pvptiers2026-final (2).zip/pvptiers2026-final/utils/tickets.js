const {
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const config = require('../config');
const { load } = require('./dataStore');

/**
 * Creates a private test ticket channel for a tester + player.
 */
async function createTestTicket(guild, testerMember, playerData, client) {
  const playerId = playerData.discordId;
  const username = (playerData.username || 'player').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'player';
  const mode = (playerData.mode || 'any').toLowerCase();
  const channelName = `test-${mode}-${username}`.slice(0, 90);

  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: playerId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks
      ]
    },
    {
      id: testerMember.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
        PermissionFlagsBits.ManageMessages
      ]
    }
  ];

  if (config.roles.admin) {
    overwrites.push({
      id: config.roles.admin,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ManageMessages
      ]
    });
  }

  const settings = load('settings');
  const categoryId = settings.ticketCategoryId || config.ticketCategoryId || null;
  let parent = null;
  if (categoryId) parent = guild.channels.cache.get(categoryId) || null;

  try {
    const channel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: parent ? parent.id : undefined,
      permissionOverwrites: overwrites,
      topic: `mode:${mode}|playerId:${playerId}|player:${playerData.username}|testerId:${testerMember.id}|tester:${testerMember.user.username}`
    });

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('🎫 Test Ticket')
      .setDescription(
        `**Player**  <@${playerId}> \`${playerData.username}\`\n` +
        `**Tester**  <@${testerMember.id}>\n` +
        `**Mode**  \`${mode.toUpperCase()}\``
      )
      .addFields({
        name: 'Buttons',
        value: '⏳ **Wait 1d** – 1 day cooldown + close\n🔒 **Close** – just close ticket',
        inline: false
      })
      .setThumbnail(playerData.uuid ? `https://mc-heads.net/avatar/${playerData.uuid}/80` : null)
      .setFooter({ text: 'pvptiers2026' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('wait_1d')
        .setLabel('Wait 1d')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('⏳'),
      new ButtonBuilder()
        .setCustomId('close_ticket')
        .setLabel('Close')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🔒')
    );

    await channel.send({
      content: `<@${playerId}> <@${testerMember.id}>`,
      embeds: [embed],
      components: [row]
    });

    return channel;
  } catch (err) {
    console.error('Failed to create ticket channel:', err);
    return null;
  }
}

function parseTicketTopic(topic) {
  if (!topic) return {};
  const result = {};
  for (const part of topic.split('|')) {
    const [key, ...rest] = part.split(':');
    if (key && rest.length) result[key.trim()] = rest.join(':').trim();
  }
  return result;
}

module.exports = { createTestTicket, parseTicketTopic };
