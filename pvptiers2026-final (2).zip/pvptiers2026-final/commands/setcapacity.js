const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setcapacity')
    .setDescription('Set how many testers can be online at the same time (Admin only)')
    .addIntegerOption(opt =>
      opt.setName('amount')
        .setDescription('New capacity (1-50)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(50)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const isAdmin = interaction.member.roles.cache.has(config.roles.admin) ||
                    interaction.member.permissions.has(PermissionFlagsBits.Administrator);

    if (!isAdmin) {
      return interaction.reply({ content: '❌ Only Admins can change capacity.', ephemeral: true });
    }

    const amount = interaction.options.getInteger('amount');
    const settings = load('settings');
    settings.capacity = amount;
    save('settings', settings);

    return interaction.reply({
      content: `✅ Tester capacity set to **${amount}**. Changes apply immediately.`
    });
  }
};
