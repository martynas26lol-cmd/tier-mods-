const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { load } = require('../utils/dataStore');
const config = require('../config');
const { getLastTest, getLastTestsByMode } = require('../utils/testersHelper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Check your (or another player) current ranks')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('User to check (default: yourself)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const users = load('users');

    if (!users[target.id]) {
      return interaction.reply({
        content: target.id === interaction.user.id
          ? '❌ You are not verified. Use `/verify` first.'
          : `❌ <@${target.id}> is not verified.`,
        ephemeral: true
      });
    }

    const data = users[target.id];
    const ranks = data.ranks || {};
    const lastByMode = getLastTestsByMode(target.id);
    const lastOverall = getLastTest(target.id);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`🏅 Ranks – ${data.username}`)
      .setDescription(`Discord: <@${target.id}>`)
      .setTimestamp()
      .setFooter({ text: 'pvptiers2026' });

    if (data.uuid) {
      embed.setThumbnail(`https://mc-heads.net/avatar/${data.uuid}/100`);
    }

    const fields = [];
    for (const mode of config.modes) {
      const rank = ranks[mode] || 'Unranked';
      let value = rank;
      if (lastByMode[mode]) {
        value += `\n<t:${Math.floor(lastByMode[mode].timestamp / 1000)}:R>`;
      }
      fields.push({ name: mode.toUpperCase(), value, inline: true });
    }

    embed.addFields(fields);

    if (lastOverall) {
      embed.addFields({
        name: 'Last Test Overall',
        value: `**${lastOverall.mode?.toUpperCase() || '?'}** → ${lastOverall.newRank} • <t:${Math.floor(lastOverall.timestamp / 1000)}:R>`,
        inline: false
      });
    }

    return interaction.reply({ embeds: [embed] });
  }
};
