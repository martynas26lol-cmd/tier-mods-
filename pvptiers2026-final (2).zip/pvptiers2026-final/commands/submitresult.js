const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');
const { getCooldownStatus, formatRemaining, COOLDOWN_MS } = require('../utils/testersHelper');
const { createResultEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('submitresult')
    .setDescription('Submit a test result (Testers only)')
    .addUserOption(opt =>
      opt.setName('player')
        .setDescription('The Discord user who was tested')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('mode')
        .setDescription('Game mode / kit')
        .setRequired(true)
        .addChoices(...config.modes.map(m => ({ name: m.toUpperCase(), value: m })))
    )
    .addStringOption(opt =>
      opt.setName('newrank')
        .setDescription('New rank given')
        .setRequired(true)
        .addChoices(...config.ranks.map(r => ({ name: r, value: r })))
    )
    .addStringOption(opt =>
      opt.setName('region')
        .setDescription('Region (default EU)')
        .setRequired(false)
        .addChoices(
          { name: 'EU', value: 'EU' },
          { name: 'NA', value: 'NA' },
          { name: 'AS', value: 'AS' },
          { name: 'SA', value: 'SA' },
          { name: 'OC', value: 'OC' }
        )
    )
    .addStringOption(opt =>
      opt.setName('stats')
        .setDescription('Optional stats or notes (e.g. 12-3, good combos)')
        .setRequired(false)
        .setMaxLength(500)
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ Only testers can submit results.', ephemeral: true });
    }

    const player = interaction.options.getUser('player');
    const mode = interaction.options.getString('mode');
    const newRank = interaction.options.getString('newrank');
    const region = interaction.options.getString('region') || 'EU';
    const stats = interaction.options.getString('stats');

    const users = load('users');
    if (!users[player.id]) {
      return interaction.reply({
        content: `❌ <@${player.id}> is not verified. They need to use \`/verify\` first.`,
        ephemeral: true
      });
    }

    // 1 day cooldown check
    const cd = getCooldownStatus(player.id, mode);
    if (cd.onCooldown) {
      const until = Math.floor((cd.lastTimestamp + COOLDOWN_MS) / 1000);
      return interaction.reply({
        content: `⏳ <@${player.id}> is on cooldown for **${mode.toUpperCase()}**.\n` +
                 `Can test again <t:${until}:R> (in ${formatRemaining(cd.remainingMs)}).\n` +
                 `Cooldown is **1 day** per mode.`,
        ephemeral: true
      });
    }

    const previousRank = users[player.id].ranks?.[mode] || 'Unranked';

    // Update rank
    if (!users[player.id].ranks) users[player.id].ranks = {};
    users[player.id].ranks[mode] = newRank;
    save('users', users);

    // Save to results history
    const results = load('results');
    const resultId = `${Date.now()}-${player.id}`;
    if (!Array.isArray(results.history)) results.history = [];
    results.history.unshift({
      id: resultId,
      playerId: player.id,
      playerName: users[player.id].username,
      testerId: interaction.user.id,
      testerName: interaction.user.username,
      mode,
      previousRank,
      newRank,
      region,
      stats,
      timestamp: Date.now()
    });
    // keep last 500
    results.history = results.history.slice(0, 500);
    save('results', results);

    // Remove from queue if present
    let queue = load('queue');
    if (Array.isArray(queue)) {
      queue = queue.filter(q => q.discordId !== player.id);
      save('queue', queue);
    }

    const embed = createResultEmbed({
      playerName: users[player.id].username,
      playerDiscordId: player.id,
      playerUuid: users[player.id].uuid,
      testerName: interaction.user.username,
      mode,
      previousRank,
      newRank,
      region,
      stats
    });

    return interaction.reply({ embeds: [embed] });
  }
};
