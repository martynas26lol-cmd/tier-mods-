const { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');
const { createQueueEmbed } = require('../utils/embeds');
const { hasTesterForMode, getOnlineTestersForMode, getCooldownStatus, formatRemaining, getBanStatus, COOLDOWN_MS } = require('../utils/testersHelper');
const { createTestersStatusEmbed } = require('../utils/embeds');
const { buildQueuePanel } = require('../utils/panel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Join, leave or view the testing queue')
    .addSubcommand(sub =>
      sub.setName('join')
        .setDescription('Join the testing queue')
        .addStringOption(opt =>
          opt.setName('mode')
            .setDescription('Preferred mode to test')
            .setRequired(false)
            .addChoices(...config.modes.map(m => ({ name: m.toUpperCase(), value: m })))
        )
    )
    .addSubcommand(sub =>
      sub.setName('leave')
        .setDescription('Leave the testing queue')
    )
    .addSubcommand(sub =>
      sub.setName('view')
        .setDescription('View current queue with Accept buttons (for testers)')
    )
    .addSubcommand(sub =>
      sub.setName('panel')
        .setDescription('Create a persistent Join/Leave Queue panel (Admin)')
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const users = load('users');
    let queue = load('queue');
    if (!Array.isArray(queue)) queue = [];

    // ========== VIEW (with Accept buttons for testers) ==========
    if (sub === 'view') {
      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);

      if (!hasTesterRole && !isAdmin) {
        return interaction.reply({
          content: '❌ Only testers and admins can view the queue with Accept buttons.\nUse the panel buttons to Join / Leave.',
          ephemeral: true
        });
      }

      const embed = createQueueEmbed(queue);
      const components = [];

      if (queue.length > 0) {
        const row1 = new ActionRowBuilder();
        const maxButtons = Math.min(queue.length, 5);
        for (let i = 0; i < maxButtons; i++) {
          row1.addComponents(
            new ButtonBuilder()
              .setCustomId(`accept_queue_${i}`)
              .setLabel(`Accept #${i + 1}`)
              .setStyle(ButtonStyle.Success)
          );
        }
        components.push(row1);

        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('accept_queue_all')
            .setLabel(`Accept All (${queue.length})`)
            .setStyle(ButtonStyle.Primary)
            .setEmoji('✅')
        );
        components.push(row2);
      }

      return interaction.reply({ 
        embeds: [embed], 
        components,
        ephemeral: true
      });
    }

    // ========== PANEL (persistent buttons) ==========
    if (sub === 'panel') {
      const isAdmin = interaction.member.roles.cache.has(config.roles.admin) ||
                      interaction.member.permissions.has('Administrator');

      if (!isAdmin) {
        return interaction.reply({ content: '❌ Only Admins can create the panel.', ephemeral: true });
      }

      // Save channel + message so bot can update panel on restart
      const payload = buildQueuePanel();
      await interaction.reply(payload);
      const reply = await interaction.fetchReply();

      const settings = load('settings');
      settings.panelChannelId = interaction.channel.id;
      settings.panelMessageId = reply.id;
      save('settings', settings);
      return;
    }

    // ========== LEAVE ==========
    if (sub === 'leave') {
      const before = queue.length;
      queue = queue.filter(item => item.discordId !== interaction.user.id);
      if (queue.length === before) {
        return interaction.reply({ content: 'You are not in the queue.', ephemeral: true });
      }
      save('queue', queue);
      return interaction.reply({ content: '✅ You left the queue.', ephemeral: true });
    }

    // ========== JOIN ==========
    if (!users[interaction.user.id]) {
      return interaction.reply({
        content: '❌ You must verify your Minecraft account first with `/verify` or the Verify button.',
        ephemeral: true
      });
    }

    // Ban check
    const ban = getBanStatus(interaction.user.id);
    if (ban) {
      const until = ban.expiresAt
        ? `<t:${Math.floor(ban.expiresAt / 1000)}:R>`
        : '**permanently**';
      return interaction.reply({
        content: `🚫 You are **banned** from testing.\n**Reason:** ${ban.reason}\nExpires: ${until}`,
        ephemeral: true
      });
    }

    if (queue.some(item => item.discordId === interaction.user.id)) {
      return interaction.reply({ content: 'You are already in the queue.', ephemeral: true });
    }

    const mode = interaction.options.getString('mode') || 'any';

    // Cooldown check
    const cd = getCooldownStatus(interaction.user.id, mode);
    if (cd.onCooldown) {
      const until = Math.floor((cd.lastTimestamp + COOLDOWN_MS) / 1000);
      return interaction.reply({
        content: `⏳ You are on cooldown for **${(cd.mode || mode).toUpperCase()}**.\n` +
                 `You can test again <t:${until}:R> (in ${formatRemaining(cd.remainingMs)}).\n` +
                 `Cooldown is **1 day** per mode.`,
        ephemeral: true
      });
    }

    // Check if there is an online tester for this mode
    if (!hasTesterForMode(mode)) {
      const online = getOnlineTestersForMode(null);
      let msg = `❌ No online tester available for **${mode.toUpperCase()}** right now.\n`;
      if (online.length === 0) {
        msg += 'There are currently **no testers online**.';
      } else {
        const modesList = [...new Set(online.flatMap(t => t.modes || []))];
        msg += `Online testers can test: \`${modesList.join(', ') || 'unknown'}\``;
      }
      return interaction.reply({ content: msg, ephemeral: true });
    }

    queue.push({
      discordId: interaction.user.id,
      username: users[interaction.user.id].username,
      uuid: users[interaction.user.id].uuid,
      mode,
      joinedAt: Date.now()
    });

    save('queue', queue);

    // Show online testers for this mode
    const onlineForMode = getOnlineTestersForMode(mode);
    let testerLines = onlineForMode.map((t, i) => {
      const modes = (t.modes && t.modes.length) ? t.modes.join(', ') : 'all';
      return `**${i + 1}.** <@${t.discordId}> – \`${modes}\``;
    }).join('\n');

    if (!testerLines) testerLines = '_No specific testers listed_';

    return interaction.reply({
      content: `✅ You joined the queue for **${mode.toUpperCase()}**. Position: **#${queue.length}**\n\n` +
               `**Online testers now:**\n${testerLines}`,
      ephemeral: true
    });
  }
};
