const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');
const { getModesFromRoles } = require('../utils/testersHelper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testback')
    .setDescription('Go online as a tester (only modes you have roles for)')
    .addStringOption(opt =>
      opt.setName('modes')
        .setDescription('Modes you want to test (comma separated). Leave empty = all your roles.')
        .setRequired(false)
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ You need a Tester role to use this command.', ephemeral: true });
    }

    // Modes allowed by roles
    const allowedModes = getModesFromRoles(member);
    if (allowedModes.length === 0 && !isAdmin) {
      return interaction.reply({
        content: '❌ You have no tester roles assigned. Contact an admin.',
        ephemeral: true
      });
    }

    const settings = load('settings');
    const capacity = settings.capacity || config.defaultCapacity;
    const testers = load('testers');

    const online = Object.values(testers).filter(t => t.online);
    if (online.length >= capacity && !testers[interaction.user.id]?.online) {
      return interaction.reply({
        content: `❌ Tester capacity full (${online.length}/${capacity}). Wait for a free slot or ask admin to raise capacity.`,
        ephemeral: true
      });
    }

    let modes = [];
    const modesStr = interaction.options.getString('modes');
    if (modesStr) {
      const requested = modesStr.split(',').map(m => m.trim().toLowerCase()).filter(m => config.modes.includes(m));
      // Only keep modes the person is allowed to test
      modes = requested.filter(m => isAdmin || allowedModes.includes(m));
      if (modes.length === 0) {
        return interaction.reply({
          content: `❌ You can only test modes you have roles for: \`${allowedModes.join(', ') || 'none'}\``,
          ephemeral: true
        });
      }
    } else {
      modes = isAdmin && allowedModes.length === 0 ? config.modes : allowedModes;
    }

    testers[interaction.user.id] = {
      discordId: interaction.user.id,
      username: interaction.user.username,
      online: true,
      modes,
      since: Date.now()
    };

    save('testers', testers);

    const modeText = modes.join(', ');
    const onlineCount = Object.values(testers).filter(t => t.online).length;
    const allowedText = allowedModes.length ? allowedModes.join(', ') : 'all (admin)';

    return interaction.reply({
      content:
        `✅ You are now **online** as tester!\n\n` +
        `**Testing modes:** \`${modeText}\`\n` +
        `**Your roles allow:** \`${allowedText}\`\n` +
        `**Online now:** **${onlineCount}/${capacity}**\n\n` +
        `Players can join the queue for these modes.\n` +
        `When finished → use \`/teststop\``
    });
  }
};
