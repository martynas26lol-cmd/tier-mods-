const { 
  SlashCommandBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle,
  EmbedBuilder,
  PermissionFlagsBits
} = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verifypanel')
    .setDescription('Create a Verify panel with button (Admin only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const isAdmin = interaction.member.roles.cache.has(config.roles.admin) ||
                    interaction.member.permissions.has(PermissionFlagsBits.Administrator);

    if (!isAdmin) {
      return interaction.reply({ content: '❌ Only Admins can create the verify panel.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle('✅ Minecraft Account Verification')
      .setDescription(
        'Press the **Verify** button below to link your Minecraft account.\n\n' +
        'After verifying you will be able to join the testing queue.'
      )
      .setFooter({ text: 'pvptiers2026' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('verify_button')
        .setLabel('Verify')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅')
    );

    return interaction.reply({ embeds: [embed], components: [row] });
  }
};
