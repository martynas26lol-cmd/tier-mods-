const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const config = require('../config');

// Default channel the user mentioned (EU test)
const DEFAULT_CHANNEL_ID = '1485652435459641404';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deleteeverything')
    .setDescription('Delete all messages written by this bot in a channel (Admin only)')
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('Channel to clean (default: EU test channel)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const isAdmin = interaction.member.roles.cache.has(config.roles.admin) ||
                    interaction.member.permissions.has(PermissionFlagsBits.Administrator);

    if (!isAdmin) {
      return interaction.reply({ content: '❌ Only Admins can use this command.', ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });

    const channel = interaction.options.getChannel('channel') ||
                    interaction.guild.channels.cache.get(DEFAULT_CHANNEL_ID) ||
                    interaction.channel;

    if (!channel || !channel.isTextBased()) {
      return interaction.editReply({ content: '❌ Invalid channel.' });
    }

    // Bot needs Manage Messages
    const me = interaction.guild.members.me;
    if (!channel.permissionsFor(me).has(PermissionFlagsBits.ManageMessages)) {
      return interaction.editReply({ content: '❌ I need **Manage Messages** permission in that channel.' });
    }

    let deleted = 0;
    let lastId = null;
    const botId = interaction.client.user.id;

    try {
      // Fetch in batches and delete bot messages
      // Discord only allows bulkDelete for messages younger than 14 days
      while (true) {
        const options = { limit: 100 };
        if (lastId) options.before = lastId;

        const messages = await channel.messages.fetch(options);
        if (messages.size === 0) break;

        const botMessages = messages.filter(m => m.author.id === botId);
        const older = []; // >14 days – delete one by one
        const newer = []; // can bulk

        const twoWeeks = Date.now() - 14 * 24 * 60 * 60 * 1000;

        for (const msg of botMessages.values()) {
          if (msg.createdTimestamp < twoWeeks) {
            older.push(msg);
          } else {
            newer.push(msg);
          }
        }

        if (newer.length > 0) {
          // bulkDelete accepts Collection or array of IDs
          const ids = newer.map(m => m.id);
          if (ids.length === 1) {
            await newer[0].delete().catch(() => {});
            deleted += 1;
          } else {
            const deletedColl = await channel.bulkDelete(ids, true).catch(() => null);
            if (deletedColl) deleted += deletedColl.size;
          }
        }

        for (const msg of older) {
          await msg.delete().catch(() => {});
          deleted += 1;
          // small delay to avoid rate limits
          await new Promise(r => setTimeout(r, 300));
        }

        lastId = messages.last()?.id;
        if (messages.size < 100) break;

        // safety: don't loop forever
        if (deleted > 2000) break;
      }

      return interaction.editReply({
        content: `✅ Deleted **${deleted}** message(s) written by me in ${channel}.`
      });
    } catch (err) {
      console.error('deleteeverything error:', err);
      return interaction.editReply({
        content: `⚠️ Deleted **${deleted}** messages, then error: ${err.message}`
      });
    }
  }
};
