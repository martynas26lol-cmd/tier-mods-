const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removerank')
    .setDescription('Remove (reset) a player rank for a specific mode (Testers/Admins)')
    .addUserOption(opt =>
      opt.setName('player')
        .setDescription('The Discord user whose rank to remove')
        .setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('mode')
        .setDescription('Game mode / kit')
        .setRequired(true)
        .addChoices(...config.modes.map(m => ({ name: m.toUpperCase(), value: m })))
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ Only testers or admins can remove ranks.', ephemeral: true });
    }

    const player = interaction.options.getUser('player');
    const mode = interaction.options.getString('mode');

    const users = load('users');
    if (!users[player.id]) {
      return interaction.reply({
        content: `❌ <@${player.id}> is not verified.`,
        ephemeral: true
      });
    }

    if (!users[player.id].ranks) users[player.id].ranks = {};

    const previousRank = users[player.id].ranks[mode] || 'Unranked';

    if (previousRank === 'Unranked' || !users[player.id].ranks[mode]) {
      return interaction.reply({
        content: `ℹ️ <@${player.id}> already has **Unranked** on **${mode.toUpperCase()}**.`,
        ephemeral: true
      });
    }

    // Reset to Unranked (or delete key)
    users[player.id].ranks[mode] = 'Unranked';
    // Optionally delete the key entirely:
    // delete users[player.id].ranks[mode];
    save('users', users);

    // Log to results history as a removal
    const results = load('results');
    if (!Array.isArray(results.history)) results.history = [];
    results.history.unshift({
      id: `${Date.now()}-${player.id}-remove`,
      playerId: player.id,
      playerName: users[player.id].username,
      testerId: interaction.user.id,
      testerName: interaction.user.username,
      mode,
      previousRank,
      newRank: 'Unranked',
      region: 'N/A',
      stats: 'Rank removed via /removerank',
      timestamp: Date.now()
    });
    results.history = results.history.slice(0, 500);
    save('results', results);

    const embed = new EmbedBuilder()
      .setColor(0xff5555)
      .setTitle('🗑️ Rank Removed')
      .setDescription(
        `**Player:** <@${player.id}> (\`${users[player.id].username}\`)\n` +
        `**Mode:** ${mode.toUpperCase()}\n` +
        `**Previous Rank:** ${previousRank}\n` +
        `**New Rank:** **Unranked**\n\n` +
        `Removed by: <@${interaction.user.id}>`
      )
      .setThumbnail(users[player.id].uuid ? `https://mc-heads.net/avatar/${users[player.id].uuid}/80` : null)
      .setTimestamp()
      .setFooter({ text: 'pvptiers2026' });

    return interaction.reply({ embeds: [embed] });
  }
};
