const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Remove a testing ban')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to unban').setRequired(true)
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ Testers/admins only.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const bans = load('bans');

    if (!bans[target.id]) {
      return interaction.reply({
        content: `ℹ️ <@${target.id}> is not banned.`,
        ephemeral: true
      });
    }

    const previous = bans[target.id];
    delete bans[target.id];
    save('bans', bans);

    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle('✅ Unbanned')
      .setDescription(
        `<@${target.id}> \`${target.username}\`\n` +
        `Previous: ${previous.reason || 'N/A'}\n` +
        `by <@${interaction.user.id}>`
      )
      .setThumbnail(target.displayAvatarURL({ size: 64 }))
      .setFooter({ text: 'pvptiers2026' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};
