const { SlashCommandBuilder } = require('discord.js');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unverify')
    .setDescription('Unlink your Minecraft account from Discord'),

  async execute(interaction) {
    const users = load('users');
    const discordId = interaction.user.id;

    if (!users[discordId]) {
      return interaction.reply({
        content: '❌ You are not verified.',
        ephemeral: true
      });
    }

    const oldName = users[discordId].username;
    delete users[discordId];
    save('users', users);

    // Also remove from queue if present
    let queue = load('queue');
    if (Array.isArray(queue)) {
      queue = queue.filter(q => q.discordId !== discordId);
      save('queue', queue);
    }

    return interaction.reply({
      content: `✅ Successfully unverified. Minecraft account **${oldName}** has been unlinked.`,
      ephemeral: true
    });
  }
};
