const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { load } = require('../utils/dataStore');
const { createTestersStatusEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testers')
    .setDescription('Show currently online testers and capacity'),

  async execute(interaction) {
    const testers = load('testers');
    const settings = load('settings');
    const capacity = settings.capacity || config.defaultCapacity;

    const online = Object.values(testers).filter(t => t.online);

    const embed = createTestersStatusEmbed(online, capacity);
    return interaction.reply({ embeds: [embed] });
  }
};
