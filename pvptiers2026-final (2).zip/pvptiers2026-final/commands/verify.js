const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { resolveUsername, formatUuid } = require('../utils/minecraft');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Link your Minecraft account to Discord')
    .addStringOption(opt =>
      opt.setName('username')
        .setDescription('Your exact Minecraft username')
        .setRequired(true)
        .setMaxLength(16)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const username = interaction.options.getString('username');
    const profile = await resolveUsername(username);

    if (!profile) {
      return interaction.editReply({
        content: `❌ Minecraft account **${username}** not found. Check spelling and try again.`
      });
    }

    const users = load('users');
    const discordId = interaction.user.id;

    for (const [uid, data] of Object.entries(users)) {
      if (data.uuid === profile.id && uid !== discordId) {
        return interaction.editReply({
          content: `❌ This Minecraft account is already linked to another Discord user.`
        });
      }
    }

    users[discordId] = {
      username: profile.name,
      uuid: profile.id,
      verifiedAt: Date.now(),
      ranks: users[discordId]?.ranks || {}
    };

    save('users', users);

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle('✅ Successfully Verified!')
      .setDescription(`**Minecraft:** ${profile.name}\n**UUID:** \`${formatUuid(profile.id)}\``)
      .setThumbnail(`https://mc-heads.net/avatar/${profile.id}/100`)
      .setImage(`https://mc-heads.net/body/${profile.id}/right`)
      .setTimestamp()
      .setFooter({ text: 'pvptiers2026' });

    return interaction.editReply({ embeds: [embed] });
  }
};
