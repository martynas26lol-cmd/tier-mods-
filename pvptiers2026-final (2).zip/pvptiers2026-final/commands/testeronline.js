const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');
const { getModesFromRoles } = require('../utils/testersHelper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('testeronline')
    .setDescription('Set yourself as online tester (same as /testback)')
    .addStringOption(opt =>
      opt.setName('modes')
        .setDescription('Modes you can test (comma separated). Leave empty for roles you have.')
        .setRequired(false)
    ),

  async execute(interaction) {
    // Re-use the same logic as /testback by requiring it
    const testback = require('./testback');
    return testback.execute(interaction);
  }
};
