const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user from testing')
    .addUserOption(opt =>
      opt.setName('user').setDescription('User to ban').setRequired(true)
    )
    .addIntegerOption(opt =>
      opt.setName('days')
        .setDescription('Days (0 = permanent)')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(365)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('Reason').setRequired(false).setMaxLength(200)
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ Testers/admins only.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const days = interaction.options.getInteger('days');
    const reason = interaction.options.getString('reason') || 'No reason';

    if (target.id === interaction.user.id) {
      return interaction.reply({ content: '❌ Cannot ban yourself.', ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ content: '❌ Cannot ban bots.', ephemeral: true });
    }

    const bans = load('bans');
    const now = Date.now();
    const expiresAt = days === 0 ? null : now + days * 24 * 60 * 60 * 1000;

    bans[target.id] = {
      discordId: target.id,
      username: target.username,
      reason,
      bannedBy: interaction.user.id,
      bannedByName: interaction.user.username,
      bannedAt: now,
      expiresAt,
      days
    };
    save('bans', bans);

    let queue = load('queue');
    if (Array.isArray(queue)) {
      const before = queue.length;
      queue = queue.filter(q => q.discordId !== target.id);
      if (queue.length !== before) save('queue', queue);
    }

    const durationText = days === 0 ? 'Permanent' : `${days}d`;
    const untilText = expiresAt
      ? `<t:${Math.floor(expiresAt / 1000)}:R>`
      : 'Never';

    const embed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle('🔨 Banned')
      .setDescription(
        `<@${target.id}> \`${target.username}\`\n` +
        `**${durationText}**  •  expires ${untilText}\n` +
        `**Reason:** ${reason}\n` +
        `by <@${interaction.user.id}>`
      )
      .setThumbnail(target.displayAvatarURL({ size: 64 }))
      .setFooter({ text: 'pvptiers2026' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  }
};
