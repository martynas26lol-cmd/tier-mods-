const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { load } = require('../utils/dataStore');
const config = require('../config');
const { getLastTest, getLastTestsByMode, getCooldownStatus, formatRemaining } = require('../utils/testersHelper');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tiers')
    .setDescription('Show a player\'s PvP tiers')
    .addUserOption(opt =>
      opt.setName('user')
        .setDescription('Discord user (default: you)')
        .setRequired(false)
    )
    .addStringOption(opt =>
      opt.setName('name')
        .setDescription('Minecraft username')
        .setRequired(false)
        .setMaxLength(16)
    ),

  async execute(interaction) {
    const users = load('users');
    let targetUser = interaction.options.getUser('user');
    const mcName = interaction.options.getString('name');

    let data = null;
    let discordId = null;
    let displayName = null;

    if (mcName) {
      const found = Object.entries(users).find(([, u]) =>
        u.username && u.username.toLowerCase() === mcName.toLowerCase()
      );
      if (!found) {
        return interaction.reply({
          content: `❌ No verified player **${mcName}**.`,
          ephemeral: true
        });
      }
      discordId = found[0];
      data = found[1];
      displayName = data.username;
    } else {
      targetUser = targetUser || interaction.user;
      discordId = targetUser.id;
      data = users[discordId];
      if (!data) {
        return interaction.reply({
          content: targetUser.id === interaction.user.id
            ? '❌ Not verified. Use `/verify`.'
            : `❌ <@${targetUser.id}> is not verified.`,
          ephemeral: true
        });
      }
      displayName = data.username;
    }

    const ranks = data.ranks || {};
    const lastByMode = getLastTestsByMode(discordId);
    const lastOverall = getLastTest(discordId);

    const rankOrder = config.ranks;
    let bestRankIndex = rankOrder.length - 1;
    for (const mode of config.modes) {
      const r = ranks[mode];
      if (r && r !== 'Unranked') {
        const idx = rankOrder.indexOf(r);
        if (idx !== -1 && idx < bestRankIndex) bestRankIndex = idx;
      }
    }
    const color = bestRankIndex <= 1 ? 0xf1c40f : bestRankIndex <= 3 ? 0xe67e22 : bestRankIndex <= 5 ? 0x3498db : 0x95a5a6;

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`🏆 ${displayName}`)
      .setDescription(`<@${discordId}>`)
      .setFooter({ text: 'pvptiers2026' })
      .setTimestamp();

    if (data.uuid) {
      embed.setThumbnail(`https://mc-heads.net/avatar/${data.uuid}/80`);
    }

    // Compact rank list – 3 per row style via short lines
    const rankLines = [];
    for (const mode of config.modes) {
      const rank = ranks[mode] || 'Unranked';
      let extra = '';
      if (lastByMode[mode]) {
        const cd = getCooldownStatus(discordId, mode);
        if (cd.onCooldown) {
          extra = ` ⏳${formatRemaining(cd.remainingMs)}`;
        }
      }
      const mark = rank === 'Unranked' ? '·' : '●';
      rankLines.push(`\`${mode.toUpperCase().padEnd(9)}\` ${mark} **${rank}**${extra}`);
    }

    embed.addFields({ name: 'Tiers', value: rankLines.join('\n'), inline: false });

    if (lastOverall) {
      embed.addFields({
        name: 'Last test',
        value: `\`${(lastOverall.mode || '?').toUpperCase()}\` → **${lastOverall.newRank}**  <t:${Math.floor(lastOverall.timestamp / 1000)}:R>`,
        inline: false
      });
    }

    return interaction.reply({ embeds: [embed] });
  }
};
