const { SlashCommandBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('teststop')
    .setDescription('Stop testing – go offline as a tester'),

  async execute(interaction) {
    const testers = load('testers');

    if (!testers[interaction.user.id] || !testers[interaction.user.id].online) {
      return interaction.reply({ content: 'You are already offline.', ephemeral: true });
    }

    testers[interaction.user.id].online = false;
    testers[interaction.user.id].since = null;
    save('testers', testers);

    const settings = load('settings');
    const capacity = settings.capacity || config.defaultCapacity;
    const onlineCount = Object.values(testers).filter(t => t.online).length;

    return interaction.reply({
      content: `🛑 You stopped testing and are now **offline**.\nCurrent online testers: **${onlineCount}/${capacity}**`
    });
  }
};
