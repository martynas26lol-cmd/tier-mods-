const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../config');
const { load, save } = require('../utils/dataStore');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('checkbans')
    .setDescription('List active testing bans')
    .addUserOption(opt =>
      opt.setName('user').setDescription('Check one user').setRequired(false)
    ),

  async execute(interaction) {
    const member = interaction.member;
    const testerRoles = Object.values(config.roles.testers);
    const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
    const isAdmin = member.roles.cache.has(config.roles.admin);

    if (!hasTesterRole && !isAdmin) {
      return interaction.reply({ content: '❌ Testers/admins only.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    let bans = load('bans');
    const now = Date.now();

    let cleaned = false;
    for (const [id, ban] of Object.entries(bans)) {
      if (ban.expiresAt && now > ban.expiresAt) {
        delete bans[id];
        cleaned = true;
      }
    }
    if (cleaned) save('bans', bans);

    if (target) {
      const ban = bans[target.id];
      if (!ban) {
        return interaction.reply({
          content: `✅ <@${target.id}> is not banned.`,
          ephemeral: true
        });
      }

      const untilText = ban.expiresAt
        ? `<t:${Math.floor(ban.expiresAt / 1000)}:R>`
        : 'Permanent';

      const embed = new EmbedBuilder()
        .setColor(0xed4245)
        .setTitle('🔨 Ban')
        .setDescription(
          `<@${target.id}> \`${ban.username || target.username}\`\n` +
          `**${ban.days === 0 ? 'Permanent' : ban.days + 'd'}**  •  ${untilText}\n` +
          `**Reason:** ${ban.reason || 'N/A'}\n` +
          `by <@${ban.bannedBy}>  •  <t:${Math.floor(ban.bannedAt / 1000)}:d>`
        )
        .setThumbnail(target.displayAvatarURL({ size: 64 }))
        .setFooter({ text: 'pvptiers2026' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const entries = Object.values(bans);
    if (entries.length === 0) {
      return interaction.reply({
        content: '✅ No active bans.',
        ephemeral: true
      });
    }

    const lines = entries.map((b, i) => {
      const exp = b.expiresAt ? `<t:${Math.floor(b.expiresAt / 1000)}:R>` : 'perm';
      return `**${i + 1}.** <@${b.discordId}>  ${b.reason || '—'}  •  ${exp}`;
    });

    const embed = new EmbedBuilder()
      .setColor(0xfaa61a)
      .setTitle(`🔨 Bans (${entries.length})`)
      .setDescription(lines.join('\n'))
      .setFooter({ text: 'pvptiers2026 • /checkbans user:@user' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
