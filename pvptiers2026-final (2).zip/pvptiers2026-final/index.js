require('dotenv').config();
const { 
  Client, 
  Collection, 
  GatewayIntentBits, 
  Events,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const { ensureDataDir, load, save } = require('./utils/dataStore');
const { resolveUsername, formatUuid } = require('./utils/minecraft');
const { createQueueEmbed } = require('./utils/embeds');
const { createTestTicket, parseTicketTopic } = require('./utils/tickets');
const { buildQueuePanel } = require('./utils/panel');
const { 
  hasTesterForMode, 
  getOnlineTestersForMode, 
  getCooldownStatus, 
  formatRemaining,
  isBanned,
  getBanStatus,
  COOLDOWN_MS
} = require('./utils/testersHelper');
const config = require('./config');

ensureDataDir();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  if ('data' in command && 'execute' in command) {
    client.commands.set(command.data.name, command);
  } else {
    console.warn(`[WARNING] The command at ${filePath} is missing required "data" or "execute" property.`);
  }
}

client.once(Events.ClientReady, async c => {
  console.log(`✅ Ready! Logged in as ${c.user.tag}`);
  console.log(`Loaded ${client.commands.size} commands.`);

  // Auto-ensure queue panel exists (edit existing or post new) so admin never needs /queue panel
  try {
    const settings = load('settings');
    const channelId = settings.panelChannelId || config.panelChannelId;
    if (channelId) {
      const channel = await client.channels.fetch(channelId).catch(() => null);
      if (channel && channel.isTextBased()) {
        const payload = buildQueuePanel();
        let updated = false;

        // Try to edit previously saved panel message
        if (settings.panelMessageId) {
          try {
            const msg = await channel.messages.fetch(settings.panelMessageId);
            await msg.edit(payload);
            updated = true;
            console.log(`📋 Queue panel updated (message ${settings.panelMessageId})`);
          } catch (_) {
            // message deleted or missing – will send new
          }
        }

        if (!updated) {
          const sent = await channel.send(payload);
          settings.panelChannelId = channelId;
          settings.panelMessageId = sent.id;
          save('settings', settings);
          console.log(`📋 Queue panel posted to channel ${channelId}`);
        }
      } else {
        console.warn(`⚠️ Panel channel ${channelId} not found or not text-based`);
      }
    }
  } catch (err) {
    console.error('Failed to auto-post queue panel:', err.message);
  }
});

/**
 * Accept one player from queue by index. Creates ticket.
 * Returns { success, player, channel, error }
 */
async function acceptPlayer(interaction, index) {
  let queue = load('queue');
  if (!Array.isArray(queue)) queue = [];

  if (index < 0 || index >= queue.length) {
    return { success: false, error: 'That queue position no longer exists.' };
  }

  const player = queue[index];

  // Remove from queue first
  queue.splice(index, 1);
  save('queue', queue);

  // Create ticket
  const channel = await createTestTicket(
    interaction.guild,
    interaction.member,
    player,
    client
  );

  return { success: true, player, channel };
}

client.on(Events.InteractionCreate, async interaction => {
  // ========== SLASH COMMANDS ==========
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (error) {
      console.error(`Error executing ${interaction.commandName}:`, error);
      const reply = { content: 'There was an error while executing this command.', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply).catch(() => {});
      } else {
        await interaction.reply(reply).catch(() => {});
      }
    }
    return;
  }

  // ========== BUTTONS ==========
  if (interaction.isButton()) {
    const id = interaction.customId;

    // ----- VERIFY BUTTON → open modal -----
    if (id === 'verify_button') {
      const modal = new ModalBuilder()
        .setCustomId('verify_modal')
        .setTitle('Minecraft Verification');

      const usernameInput = new TextInputBuilder()
        .setCustomId('minecraft_username')
        .setLabel('Your Minecraft Username')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('e.g. Notch')
        .setRequired(true)
        .setMaxLength(16)
        .setMinLength(1);

      modal.addComponents(new ActionRowBuilder().addComponents(usernameInput));
      return interaction.showModal(modal);
    }

    // ----- QUEUE JOIN BUTTON -----
    if (id === 'queue_join') {
      const users = load('users');
      let queue = load('queue');
      if (!Array.isArray(queue)) queue = [];

      if (!users[interaction.user.id]) {
        return interaction.reply({
          content: '❌ You must verify first. Use the **Verify** button or `/verify`.',
          ephemeral: true
        });
      }

      // Ban check
      const ban = getBanStatus(interaction.user.id);
      if (ban) {
        const until = ban.expiresAt
          ? `<t:${Math.floor(ban.expiresAt / 1000)}:R>`
          : '**permanently**';
        return interaction.reply({
          content: `🚫 You are **banned** from testing.\n**Reason:** ${ban.reason}\nExpires: ${until}`,
          ephemeral: true
        });
      }

      if (queue.some(q => q.discordId === interaction.user.id)) {
        return interaction.reply({ content: 'You are already in the queue.', ephemeral: true });
      }

      // Cooldown (any mode)
      const cd = getCooldownStatus(interaction.user.id, 'any');
      if (cd.onCooldown) {
        const until = Math.floor((cd.lastTimestamp + COOLDOWN_MS) / 1000);
        return interaction.reply({
          content: `⏳ You are on cooldown. You can test again <t:${until}:R> (in ${formatRemaining(cd.remainingMs)}).\nCooldown is **1 day**.`,
          ephemeral: true
        });
      }

      // Button join uses mode "any" – require at least one online tester
      if (!hasTesterForMode('any')) {
        return interaction.reply({
          content: '❌ No testers are online right now. You cannot join the queue.',
          ephemeral: true
        });
      }

      queue.push({
        discordId: interaction.user.id,
        username: users[interaction.user.id].username,
        uuid: users[interaction.user.id].uuid,
        mode: 'any',
        joinedAt: Date.now()
      });
      save('queue', queue);

      const online = getOnlineTestersForMode('any');
      let testerLines = online.map((t, i) => {
        const modes = (t.modes && t.modes.length) ? t.modes.join(', ') : 'all';
        return `**${i + 1}.** <@${t.discordId}> – \`${modes}\``;
      }).join('\n') || '_None_';

      return interaction.reply({
        content: `✅ You joined the queue. Position: **#${queue.length}**\n\n**Online testers now:**\n${testerLines}`,
        ephemeral: true
      });
    }

    // ----- QUEUE LEAVE BUTTON -----
    if (id === 'queue_leave') {
      let queue = load('queue');
      if (!Array.isArray(queue)) queue = [];

      const before = queue.length;
      queue = queue.filter(q => q.discordId !== interaction.user.id);

      if (queue.length === before) {
        return interaction.reply({ content: 'You are not in the queue.', ephemeral: true });
      }

      save('queue', queue);
      return interaction.reply({ content: '✅ You left the queue.', ephemeral: true });
    }

    // ----- QUEUE VIEW BUTTON -----
    if (id === 'queue_view') {
      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);

      if (!hasTesterRole && !isAdmin) {
        return interaction.reply({
          content: '❌ Only testers and admins can view the queue.',
          ephemeral: true
        });
      }

      let queue = load('queue');
      if (!Array.isArray(queue)) queue = [];

      const embed = createQueueEmbed(queue);
      const components = [];

      if (queue.length > 0) {
        const row1 = new ActionRowBuilder();
        const maxButtons = Math.min(queue.length, 5);
        for (let i = 0; i < maxButtons; i++) {
          row1.addComponents(
            new ButtonBuilder()
              .setCustomId(`accept_queue_${i}`)
              .setLabel(`Accept #${i + 1}`)
              .setStyle(ButtonStyle.Success)
          );
        }
        components.push(row1);

        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('accept_queue_all')
            .setLabel(`Accept All (${queue.length})`)
            .setStyle(ButtonStyle.Primary)
            .setEmoji('✅')
        );
        components.push(row2);
      }

      return interaction.reply({
        embeds: [embed],
        components,
        ephemeral: true
      });
    }

    // ----- ACCEPT #1 / #2 / #3 ... BUTTONS -----
    if (id.startsWith('accept_queue_') && id !== 'accept_queue_all') {
      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);

      if (!hasTesterRole && !isAdmin) {
        return interaction.reply({ content: '❌ Only testers can accept players.', ephemeral: true });
      }

      await interaction.deferReply({ ephemeral: false });

      const index = parseInt(id.replace('accept_queue_', ''), 10);
      const result = await acceptPlayer(interaction, index);

      if (!result.success) {
        return interaction.editReply({ content: `❌ ${result.error}` });
      }

      const { player, channel } = result;

      const embed = new EmbedBuilder()
        .setColor(0x00ff88)
        .setTitle('✅ Accepted')
        .setDescription(
          `<@${interaction.user.id}> → <@${player.discordId}> \`${player.username}\`\n` +
          `Mode: \`${(player.mode || 'any').toUpperCase()}\`\n` +
          (channel ? `🎫 ${channel}` : '⚠️ Ticket failed')
        )
        .setThumbnail(player.uuid ? `https://mc-heads.net/avatar/${player.uuid}/64` : null)
        .setFooter({ text: 'pvptiers2026' })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      // Try to DM the player
      try {
        const user = await client.users.fetch(player.discordId);
        await user.send(
          `You have been **accepted** by tester **${interaction.user.username}**!\n` +
          (channel ? `Go to your ticket: ${channel}` : 'Get ready for your test.')
        );
      } catch (e) {
        // DMs closed – ignore
      }

      return;
    }

    // ----- ACCEPT ALL BUTTON -----
    if (id === 'accept_queue_all') {
      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);

      if (!hasTesterRole && !isAdmin) {
        return interaction.reply({ content: '❌ Only testers can accept players.', ephemeral: true });
      }

      await interaction.deferReply({ ephemeral: false });

      let queue = load('queue');
      if (!Array.isArray(queue) || queue.length === 0) {
        return interaction.editReply({ content: '❌ Queue is empty.' });
      }

      // Limit to 10 at once to avoid rate limits / spam
      const toAccept = queue.slice(0, 10);
      const accepted = [];
      const failed = [];

      // Save remaining first
      const remaining = queue.slice(toAccept.length);
      save('queue', remaining);

      for (const player of toAccept) {
        try {
          const channel = await createTestTicket(
            interaction.guild,
            interaction.member,
            player,
            client
          );
          accepted.push({ player, channel });

          // DM
          try {
            const user = await client.users.fetch(player.discordId);
            await user.send(
              `You have been **accepted** by tester **${interaction.user.username}**!\n` +
              (channel ? `Go to your ticket: ${channel}` : 'Get ready for your test.')
            );
          } catch (_) {}
        } catch (err) {
          console.error('Accept all error for', player.discordId, err);
          failed.push(player);
        }
      }

      const lines = accepted.map((a, i) => {
        const ch = a.channel ? a.channel.toString() : 'no ticket';
        return `**${i + 1}.** <@${a.player.discordId}> (\`${a.player.username}\`) → ${ch}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x00ff88)
        .setTitle(`✅ Accepted ${accepted.length} player(s)`)
        .setDescription(
          lines.join('\n') +
          (failed.length ? `\n\n⚠️ Failed: ${failed.length}` : '') +
          (queue.length > 10 ? `\n\n_Only first 10 were accepted. ${queue.length - 10} remain in queue._` : '')
        )
        .setTimestamp()
        .setFooter({ text: 'pvptiers2026' });

      return interaction.editReply({ embeds: [embed] });
    }

    // ----- WAIT 2D BUTTON (ticket) -----
    if (id === 'wait_1d') {
      const channel = interaction.channel;
      if (!channel || !channel.name.startsWith('test-')) {
        return interaction.reply({ content: '❌ This is not a test ticket.', ephemeral: true });
      }

      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);
      const canUse = hasTesterRole || isAdmin || member.permissions.has(PermissionFlagsBits.ManageChannels);

      if (!canUse) {
        return interaction.reply({ content: '❌ Only testers or admins can use this button.', ephemeral: true });
      }

      const topicData = parseTicketTopic(channel.topic || '');
      const playerId = topicData.playerId;
      const mode = (topicData.mode || 'any').toLowerCase();
      const playerName = topicData.player || 'Unknown';

      if (!playerId) {
        return interaction.reply({
          content: '❌ Could not read player info from this ticket. Close it manually.',
          ephemeral: true
        });
      }

      // Apply 2-day cooldown by adding a special history entry
      const results = load('results');
      if (!Array.isArray(results.history)) results.history = [];

      results.history.unshift({
        id: `${Date.now()}-${playerId}-wait1d`,
        playerId,
        playerName,
        testerId: interaction.user.id,
        testerName: interaction.user.username,
        mode,
        previousRank: 'N/A',
        newRank: 'N/A',
        region: 'N/A',
        stats: 'Wait 1d applied via ticket button (no rank change)',
        timestamp: Date.now()
      });
      results.history = results.history.slice(0, 500);
      save('results', results);

      // Remove from queue if still there
      let queue = load('queue');
      if (Array.isArray(queue)) {
        queue = queue.filter(q => q.discordId !== playerId);
        save('queue', queue);
      }

      const until = Math.floor((Date.now() + COOLDOWN_MS) / 1000);

      const embed = new EmbedBuilder()
        .setColor(0xfaa61a)
        .setTitle('⏳ Wait 1d')
        .setDescription(
          `<@${playerId}> \`${playerName}\`  •  \`${mode.toUpperCase()}\`\n` +
          `Cooldown until <t:${until}:R>\n` +
          `Ticket closes in a few seconds...`
        )
        .setFooter({ text: 'pvptiers2026' })
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      setTimeout(async () => {
        try {
          await channel.delete(`Wait 1d by ${interaction.user.tag}`);
        } catch (e) {
          console.error('Failed to delete ticket after wait_1d:', e);
        }
      }, 4000);

      return;
    }

    // ----- CLOSE TICKET BUTTON -----
    if (id === 'close_ticket') {
      const channel = interaction.channel;
      if (!channel || !channel.name.startsWith('test-')) {
        return interaction.reply({ content: '❌ This is not a test ticket.', ephemeral: true });
      }

      const member = interaction.member;
      const testerRoles = Object.values(config.roles.testers);
      const hasTesterRole = member.roles.cache.some(r => testerRoles.includes(r.id));
      const isAdmin = member.roles.cache.has(config.roles.admin);
      const canClose = hasTesterRole || isAdmin || member.permissions.has(PermissionFlagsBits.ManageChannels);

      if (!canClose) {
        return interaction.reply({ content: '❌ Only testers or admins can close tickets.', ephemeral: true });
      }

      await interaction.reply({ content: '🔒 Ticket will be closed in 3 seconds...' });

      setTimeout(async () => {
        try {
          await channel.delete('Ticket closed by ' + interaction.user.tag);
        } catch (e) {
          console.error('Failed to delete ticket channel:', e);
        }
      }, 3000);

      return;
    }
  }

  // ========== MODAL SUBMIT (Verify) ==========
  if (interaction.isModalSubmit() && interaction.customId === 'verify_modal') {
    await interaction.deferReply({ ephemeral: true });

    const username = interaction.fields.getTextInputValue('minecraft_username');
    const profile = await resolveUsername(username);

    if (!profile) {
      return interaction.editReply({
        content: `❌ Minecraft account **${username}** not found. Check spelling and try again.`
      });
    }

    const users = load('users');
    const discordId = interaction.user.id;

    for (const [uid, data] of Object.entries(users)) {
      if (data.uuid === profile.id && uid !== discordId) {
        return interaction.editReply({
          content: `❌ This Minecraft account is already linked to another Discord user.`
        });
      }
    }

    users[discordId] = {
      username: profile.name,
      uuid: profile.id,
      verifiedAt: Date.now(),
      ranks: users[discordId]?.ranks || {}
    };
    save('users', users);

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle('✅ Successfully Verified!')
      .setDescription(`**Minecraft:** ${profile.name}\n**UUID:** \`${formatUuid(profile.id)}\``)
      .setThumbnail(`https://mc-heads.net/avatar/${profile.id}/100`)
      .setImage(`https://mc-heads.net/body/${profile.id}/right`)
      .setTimestamp()
      .setFooter({ text: 'pvptiers2026' });

    return interaction.editReply({ embeds: [embed] });
  }
});

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error('❌ DISCORD_TOKEN is missing in .env');
  process.exit(1);
}

client.login(token);
