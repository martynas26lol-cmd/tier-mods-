# pvptiers2026

Discord botas Minecraft PvP tierų sistemai.

## Naujos funkcijos

### 🔨 Ban
```
/ban user:@user days:7 reason:toxic
/unban user:@user
/checkbans
/checkbans user:@user
```

### 🏆 /tiers
```
/tiers
/tiers user:@user
/tiers name:Notch
```

### ⏳ Ticket mygtukai
Kai acceptini → ticketas su:
- **Wait 1d** – 1 dienos cooldown + uždaro
- **Close** – tik uždaro

### 📋 Queue panel
Automatiškai atsiranda paleidus botą (nereikia `/queue panel`).

### Cooldown
**1 diena** po testo arba **Wait 1d**.

## Komandos

| Komanda | Aprašymas |
|---------|-----------|
| `/verify` | Discord ↔ Minecraft |
| `/testeronline [modes]` | Eiti online |
| `/testback [modes]` | Tas pats |
| `/testeroffline` `/teststop` | Offline |
| `/testers` | Online testeriai |
| `/setcapacity` | Talpa |
| `/queue join/leave/view/panel` | Eilė |
| `/submitresult` | Rezultatas |
| `/rank` `/tiers` | Rangai |
| `/removerank` | Ištrinti rangą |
| `/ban` `/unban` `/checkbans` | Banai |
| `/deleteeverything` | Ištrinti bot žinutes |
| `/unverify` | Atsieti |

## Paleidimas

```bash
npm install
# .env: DISCORD_TOKEN, CLIENT_ID, GUILD_ID
npm run deploy
npm start
```

Reikia: Manage Channels, Manage Messages, Send Messages, Embed Links.
