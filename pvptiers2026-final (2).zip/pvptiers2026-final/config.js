module.exports = {
  // Role IDs provided by server owner
  roles: {
    admin: '1489691746345418932',
    testers: {
      spearmace: '1494719664855711895',
      sword: '1489693729198575726',
      axe: '1489693801957298366',
      smp: '1489693890218033233',
      cpvp: '1489694008111403188',
      pot: '1489694112427806890',
      uhc: '1489693956668260543',
      mace: '1489693546511470802',
      nethpot: '1489693639956496504'
    }
  },

  // Supported game modes / kits
  modes: [
    'sword',
    'axe',
    'smp',
    'cpvp',
    'pot',
    'uhc',
    'mace',
    'nethpot',
    'spearmace'
  ],

  // Possible ranks (from highest to lowest typical PvP tier style)
  ranks: ['HT1', 'LT1', 'HT2', 'LT2', 'HT3', 'LT3', 'HT4', 'LT4', 'HT5', 'LT5', 'Unranked'],

  // Default tester capacity
  defaultCapacity: 5,

  // Optional: Discord category ID where test tickets will be created.
  ticketCategoryId: null,

  // Channel where the queue panel is auto-posted on bot start.
  // Set this to your queue channel ID so you never need /queue panel again.
  panelChannelId: '1485652435459641404',

  // Cooldown after a test or "Wait 1d" button (1 day)
  cooldownMs: 24 * 60 * 60 * 1000,

  // Data file paths
  dataFiles: {
    users: './data/users.json',
    testers: './data/testers.json',
    queue: './data/queue.json',
    results: './data/results.json',
    settings: './data/settings.json',
    bans: './data/bans.json'
  }
};
