package com.pvptiers.mod.data;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.*;

/**
 * Thread-safe tier cache.
 *
 * Kaip veikia:
 *  1. Pirmas kartas matant žaidėją – UNRANKED, pradeda async API fetch
 *  2. API grąžina atsakymą – įrašoma į cache su timestamp
 *  3. Po TTL_MS milisekundžių – cache pasensta, kitą kartą vėl fetched
 *
 * Naudojamas pvptierslist.com viešas API.
 * Jei nori PvPTiersLol – pakeisk API_URL.
 */
public class TierCache {

    private static final Logger LOGGER = LoggerFactory.getLogger("pvptiers");

    // ── Keisk čia jei nori kito API ──────────────────────────────────
    // MCTiers style API. UUID be brūkšnelių.
    private static final String API_URL = "https://api.pvptierslist.com/v1/player/%s";
    // Arba PvPTiersLol:
    // private static final String API_URL = "https://pvptierslist.com/api/v1/%s";
    // ─────────────────────────────────────────────────────────────────

    /** Cache gyvavimo laikas milisekundėmis (5 minutės) */
    private static final long TTL_MS = 5 * 60 * 1000L;

    /** UUID kuriems šiuo metu vyksta fetch (kad nekartotų) */
    private static final ConcurrentHashMap<UUID, Boolean> pendingFetches = new ConcurrentHashMap<>();

    /** Pagrindinis cache: UUID → CachedTier */
    private static final ConcurrentHashMap<UUID, CachedEntry> cache = new ConcurrentHashMap<>();

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private static final ExecutorService EXECUTOR = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "pvptiers-fetch");
        t.setDaemon(true);
        return t;
    });

    // ─────────────────────────────────────────────────────────────────

    /**
     * Gauna tier pagal UUID.
     * Jei cache tuščias arba pasenęs – prasideda async fetch, kol kas grąžina UNRANKED.
     */
    public static Tier getTier(UUID uuid) {
        CachedEntry entry = cache.get(uuid);

        if (entry != null && !entry.isExpired()) {
            return entry.tier;
        }

        // Pradeda fetch jei dar nevyksta
        if (pendingFetches.putIfAbsent(uuid, Boolean.TRUE) == null) {
            fetchAsync(uuid);
        }

        // Kol fetch vyksta – grąžina seną reikšmę arba UNRANKED
        return entry != null ? entry.tier : Tier.UNRANKED;
    }

    /**
     * Tiesiogiai įdeda tier į cache (pvz. iš komandos /pvptiers set).
     */
    public static void putTier(UUID uuid, Tier tier) {
        cache.put(uuid, new CachedEntry(tier));
    }

    /**
     * Išvalo visą cache (pvz. keičiantis serveriui).
     */
    public static void clear() {
        cache.clear();
        pendingFetches.clear();
    }

    // ─── Private ─────────────────────────────────────────────────────

    private static void fetchAsync(UUID uuid) {
        EXECUTOR.submit(() -> {
            try {
                Tier tier = fetchFromApi(uuid);
                cache.put(uuid, new CachedEntry(tier));
                LOGGER.debug("Fetched tier for {}: {}", uuid, tier);
            } catch (Exception e) {
                LOGGER.warn("Nepavyko gauti tier {}: {}", uuid, e.getMessage());
                // Įdeda UNRANKED su trumpesniu TTL (1 min) kad vėliau pabandytų dar kartą
                cache.put(uuid, new CachedEntry(Tier.UNRANKED, 60_000L));
            } finally {
                pendingFetches.remove(uuid);
            }
        });
    }

    private static Tier fetchFromApi(UUID uuid) throws Exception {
        // UUID be brūkšnelių pvz. "550e8400e29b41d4a716446655440000"
        String uuidStr = uuid.toString().replace("-", "");
        String url = String.format(API_URL, uuidStr);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("User-Agent", "PvPTiersMod/1.0 Minecraft")
                .GET()
                .build();

        HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 404) {
            return Tier.UNRANKED; // Žaidėjas neranked
        }
        if (response.statusCode() != 200) {
            throw new RuntimeException("HTTP " + response.statusCode());
        }

        return parseTierFromJson(response.body());
    }

    /**
     * Parsina tier iš API JSON atsakymo.
     *
     * Tikėtinas JSON formatas:
     * { "tier": "HT2", "uuid": "...", "username": "..." }
     *
     * Jei API grąžina kitaip – koreguok čia.
     */
    private static Tier parseTierFromJson(String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            // Bandome kelis galimus field pavadinimus
            String tierStr = null;
            if (obj.has("tier"))       tierStr = obj.get("tier").getAsString();
            else if (obj.has("rank"))  tierStr = obj.get("rank").getAsString();
            else if (obj.has("score")) tierStr = obj.get("score").getAsString();
            return Tier.fromString(tierStr);
        } catch (Exception e) {
            LOGGER.warn("JSON parse klaida: {}", e.getMessage());
            return Tier.UNRANKED;
        }
    }

    // ─── Inner record ─────────────────────────────────────────────────

    private static final class CachedEntry {
        final Tier tier;
        final long expiresAt;

        CachedEntry(Tier tier) {
            this(tier, TTL_MS);
        }

        CachedEntry(Tier tier, long ttlMs) {
            this.tier      = tier;
            this.expiresAt = System.currentTimeMillis() + ttlMs;
        }

        boolean isExpired() {
            return System.currentTimeMillis() > expiresAt;
        }
    }
}
