package com.pvptiers.mod.data;

/**
 * Visi galimi PvP tieriai pagal MCTiers / PvPTiersLol sistemą.
 *
 * Tier tvarka (geriausias → blogiausias):
 *   HT1, LT1, HT2, LT2, HT3, LT3, HT4, LT4, HT5, LT5, HT6, LT6, O, NE, B, A
 *
 * Spalvos atitinka standartines MCTiers spalvas.
 */
public enum Tier {

    // ─── High/Low Tier 1-6 ───────────────────────────────────────────
    HT1("HT1", 0xFF5555, 1),  // Ryškiai raudona  – aukščiausias
    LT1("LT1", 0xFF7777, 2),
    HT2("HT2", 0xFF9955, 3),  // Oranžinė
    LT2("LT2", 0xFFBB77, 4),
    HT3("HT3", 0xFFFF55, 5),  // Geltona
    LT3("LT3", 0xFFFF99, 6),
    HT4("HT4", 0x55FF55, 7),  // Žalia
    LT4("LT4", 0x99FF99, 8),
    HT5("HT5", 0x55FFFF, 9),  // Žydra
    LT5("LT5", 0x99FFFF, 10),
    HT6("HT6", 0xAAAAAA, 11), // Pilka
    LT6("LT6", 0xCCCCCC, 12),

    // ─── Žemesni rankingai ───────────────────────────────────────────
    O  ("O",   0xFFAA00, 13), // Oranžinė (Overrated)
    NE ("NE",  0x888888, 14), // Pilka     (Not Enough info)
    B  ("B",   0x5555FF, 15), // Mėlyna
    A  ("A",   0x7777FF, 16), // Šviesiai mėlyna

    // ─── Nežinomas / nerinktas ───────────────────────────────────────
    UNRANKED("?", 0x555555, 99);

    /** Tekstas rodomas ekrane */
    public final String label;
    /** ARGB spalva (be alpha = visiškai matoma) */
    public final int color;
    /** Rūšiavimui (kuo mažesnis, tuo geresnis) */
    public final int rank;

    Tier(String label, int color, int rank) {
        this.label = label;
        this.color = color | 0xFF000000; // prideda alpha
        this.rank  = rank;
    }

    /**
     * Paverčia API string į Tier enum.
     * API gali grąžinti: "HT1", "ht1", "LT3", "O", "NE", "B", "A" ir t.t.
     */
    public static Tier fromString(String raw) {
        if (raw == null || raw.isBlank()) return UNRANKED;
        String upper = raw.strip().toUpperCase();
        for (Tier t : values()) {
            if (t.label.equals(upper)) return t;
        }
        return UNRANKED;
    }

    /** Grąžina tier spalvą kaip 0xAARRGGBB int (Minecraft formatas) */
    public int getArgbColor() {
        return color;
    }

    @Override
    public String toString() {
        return label;
    }
}
