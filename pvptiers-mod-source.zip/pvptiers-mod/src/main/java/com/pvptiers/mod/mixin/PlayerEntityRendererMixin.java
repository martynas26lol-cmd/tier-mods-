package com.pvptiers.mod.mixin;

import com.pvptiers.mod.data.Tier;
import com.pvptiers.mod.data.TierCache;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;

/**
 * Įsiterpia į PlayerEntityRenderer.renderLabelIfPresent()
 * ir rodo tier tekstą VIRŠ standartinio nametag.
 *
 * Tier rodymo tvarka (iš viršaus žemyn):
 *   [HT2]        ← mūsų pridėtas tier label
 *   PlayerName   ← originalus Minecraft nametag
 *   ❤❤❤          ← health bar (jei įjungta)
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin
        extends LivingEntityRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {

    public PlayerEntityRendererMixin(EntityRendererFactory.Context ctx,
                                     PlayerEntityModel<AbstractClientPlayerEntity> model,
                                     float shadowRadius) {
        super(ctx, model, shadowRadius);
    }

    /**
     * Injektas HEAD – vykdomas prieš originalų renderLabelIfPresent.
     * Piešiame tier label šiek tiek aukščiau nei originalus nametag.
     */
    @Inject(
        method = "renderLabelIfPresent",
        at = @At("HEAD")
    )
    private void renderTierLabel(AbstractClientPlayerEntity player,
                                  Text text,
                                  MatrixStack matrices,
                                  VertexConsumerProvider vertexConsumers,
                                  int light,
                                  float tickDelta,
                                  CallbackInfo ci) {

        // Nerodo jei žaidėjas yra invisible arba per toli
        if (player.isInvisibleTo(getMinecraftClient().player)) return;
        if (this.dispatcher.getSquaredDistanceToCamera(player) > 4096) return; // 64 blokų ribą

        UUID uuid = player.getUuid();
        Tier tier = TierCache.getTier(uuid);

        // Nerodo jei UNRANKED (galima pašalinti jei nori rodyti "?" visiems)
        if (tier == Tier.UNRANKED) return;

        // ── Pozicija ─────────────────────────────────────────────────
        // originalus nametag yra ties player.getHeight() + 0.5
        // mes keliame dar 0.3 aukščiau
        float nameTagY   = player.getHeight() + 0.5f;
        float tierLabelY = nameTagY + 0.30f;

        matrices.push();
        matrices.translate(0.0, tierLabelY, 0.0);

        // Visada žiūri į kamerą (billboard efektas)
        matrices.multiply(this.dispatcher.getRotation());

        // Mažesnis mastelis nei originalus nametag
        float scale = 0.025f;
        matrices.scale(-scale, -scale, scale);

        // ── Tekstas ──────────────────────────────────────────────────
        Matrix4f matrix    = matrices.peek().getPositionMatrix();
        TextRenderer font   = this.getTextRenderer();
        String label        = tier.label;
        float textWidth     = font.getWidth(label);
        float x             = -textWidth / 2.0f;

        // Fonas (pusiau permatoma juoda dėžutė)
        int bgColor = (int)(MinecraftClient.getInstance().options
                .getTextBackgroundOpacity(0.25f) * 255.0f) << 24;

        font.draw(
            label,
            x, 0f,
            tier.getArgbColor(),
            false,            // shadow=false (originale taip pat false)
            matrix,
            vertexConsumers,
            TextRenderer.TextLayerType.SEE_THROUGH,
            bgColor,
            light
        );

        matrices.pop();
    }

    /**
     * Pagalbinis metodas gauti MinecraftClient instanciją iš renderer konteksto.
     */
    private net.minecraft.client.MinecraftClient getMinecraftClient() {
        return net.minecraft.client.MinecraftClient.getInstance();
    }
}
